#directory "./lambda";;
#load_rec "./lambda/syntax.cmo";;
#load_rec "./lambda/lambda_parse.cmo";;
#load_rec "./lambda/alpha.cmo";;

let alpha_equiv = Alpha.alpha_equiv
